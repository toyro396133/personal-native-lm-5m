# Blind Follow-up Benchmark Machine Summary

## F1
```json
{
  "full_beta_ci95": {
    "effect_norm": [
      -0.3053784586677802,
      -0.14546545358196208
    ],
    "negate": [
      0.01448877013674459,
      0.0834028771816478
    ],
    "shuffle": [
      -0.004045725064096175,
      0.0012593023672134813
    ]
  },
  "full_beta_effect_norm": -0.22840608385338831,
  "full_beta_negate": 0.050297486516260745,
  "full_beta_shuffle": -0.0012268125909673014,
  "full_r2_within": 0.2689887761597799,
  "full_sse": 1.7463045902849699,
  "leave_group_out_improvement_fraction": 0.020821586882780376,
  "leave_group_out_sse_mag_only": 1.8124205993958102,
  "leave_group_out_sse_mag_plus_mode": 1.7746831264173495,
  "magnitude_only_beta": -0.12640325388600127,
  "magnitude_only_r2_within": 0.24836231847037382,
  "magnitude_only_sse": 1.7955789058763287,
  "n_checkpoint_layers": 252,
  "n_rows": 756,
  "sse_improvement_fraction": 0.027442021862754414
}
```

## F2
```json
{
  "B": {
    "ci95_cluster_checkpoint": [
      0.0003921552085953299,
      0.002017965671960323
    ],
    "learned_adv_mean_abs": 0.0026062426098164117,
    "mean": 0.0012276594612478015,
    "median": 0.0010143452634414074,
    "n": 252,
    "negative_fraction": 0.38095238095238093,
    "per_variant": {
      "V2": {
        "mean": -0.0005044209223891242,
        "median": -0.0009533851924869441,
        "n": 42,
        "negative_fraction": 0.7380952380952381,
        "positive_fraction": 0.2619047619047619
      },
      "V3": {
        "mean": -0.00245390994149067,
        "median": -0.002515029720962042,
        "n": 42,
        "negative_fraction": 0.9523809523809523,
        "positive_fraction": 0.047619047619047616
      },
      "V4": {
        "mean": 0.004394184777306175,
        "median": 0.004234122567706666,
        "n": 42,
        "negative_fraction": 0.0,
        "positive_fraction": 1.0
      },
      "V5": {
        "mean": 0.0009186010275568144,
        "median": 0.0008414239312211913,
        "n": 42,
        "negative_fraction": 0.2857142857142857,
        "positive_fraction": 0.7142857142857143
      },
      "V6": {
        "mean": 0.0031363627168709725,
        "median": 0.002843930096262076,
        "n": 42,
        "negative_fraction": 0.09523809523809523,
        "positive_fraction": 0.9047619047619048
      },
      "V7": {
        "mean": 0.0018751391096326422,
        "median": 0.0015334891569283304,
        "n": 42,
        "negative_fraction": 0.21428571428571427,
        "positive_fraction": 0.7857142857142857
      }
    },
    "positive_fraction": 0.6190476190476191,
    "shuffle_random_noise_mean_abs": 0.003752654682798898
  },
  "C": {
    "ci95_cluster_checkpoint": [
      -0.0030907029064283463,
      0.0028104768964138382
    ],
    "learned_adv_mean_abs": 0.007674225322521137,
    "mean": 4.474357480094811e-06,
    "median": 0.00020447903209269702,
    "n": 252,
    "negative_fraction": 0.4801587301587302,
    "per_variant": {
      "V2": {
        "mean": 0.00028800296562688947,
        "median": 0.0002576073010762403,
        "n": 42,
        "negative_fraction": 0.4523809523809524,
        "positive_fraction": 0.5476190476190477
      },
      "V3": {
        "mean": -0.003861797896642533,
        "median": -0.0031133645110660024,
        "n": 42,
        "negative_fraction": 0.8809523809523809,
        "positive_fraction": 0.11904761904761904
      },
      "V4": {
        "mean": 0.00729069428311453,
        "median": 0.007407883803049742,
        "n": 42,
        "negative_fraction": 0.047619047619047616,
        "positive_fraction": 0.9523809523809523
      },
      "V5": {
        "mean": -0.015725562946190916,
        "median": -0.015605731308460213,
        "n": 42,
        "negative_fraction": 1.0,
        "positive_fraction": 0.0
      },
      "V6": {
        "mean": 0.01148745309581203,
        "median": 0.01151918868223828,
        "n": 42,
        "negative_fraction": 0.023809523809523808,
        "positive_fraction": 0.9761904761904762
      },
      "V7": {
        "mean": 0.0005480566431605703,
        "median": 9.538680315016035e-05,
        "n": 42,
        "negative_fraction": 0.47619047619047616,
        "positive_fraction": 0.5238095238095238
      }
    },
    "positive_fraction": 0.5198412698412699,
    "shuffle_random_noise_mean_abs": 0.012264302443890342
  }
}
```

## F3
```json
{
  "centered_correlations": {
    "gate": {
      "pearson_centered": 0.006962132225731032,
      "spearman_centered": -0.06554257612022052
    },
    "path_down_norm": {
      "pearson_centered": 0.13064434530616517,
      "spearman_centered": 0.1421641124566856
    },
    "path_up_norm": {
      "pearson_centered": 0.21399451261546878,
      "spearman_centered": 0.2344431345931721
    }
  },
  "lag_regression": {
    "beta_gate": 0.02172499513597689,
    "beta_path_down": -0.0556431366181016,
    "beta_path_up": 0.15651356962103533,
    "null_r2_95": [
      0.0024391058816967933,
      0.12006613359091081
    ],
    "null_r2_mean": 0.03523059186700461,
    "permutation_p": 0.6282743451309738,
    "r2": 0.018611884971238668
  },
  "n_checkpoints": 36,
  "n_layer_rows": 216,
  "same_layer_regression": {
    "beta_gate": -0.18129551668008292,
    "beta_path_down": 0.0671588230973618,
    "beta_path_up": 0.2660227042812058,
    "r2": 0.0644391160633343
  }
}
```

## F4
```json
{
  "ci95_cluster_checkpoint": [
    -0.05139833711262283,
    -0.03212396069538927
  ],
  "mean": -0.041320231796422274,
  "median": -0.01851851851851849,
  "n": 294,
  "negative_fraction": 0.673469387755102,
  "per_token": {
    "100": {
      "mean": -0.061602418745275896,
      "median": -0.03703703703703709,
      "n": 49,
      "negative_fraction": 0.7755102040816326
    },
    "110": {
      "mean": -0.03325774754346183,
      "median": -0.01851851851851849,
      "n": 49,
      "negative_fraction": 0.6326530612244898
    },
    "120": {
      "mean": -0.01927437641723356,
      "median": -0.01851851851851849,
      "n": 49,
      "negative_fraction": 0.5306122448979592
    },
    "25": {
      "mean": -0.07180650037792895,
      "median": -0.05555555555555558,
      "n": 49,
      "negative_fraction": 0.8979591836734694
    },
    "50": {
      "mean": -0.03590325018896447,
      "median": -0.01851851851851849,
      "n": 49,
      "negative_fraction": 0.6326530612244898
    },
    "75": {
      "mean": -0.02607709750566894,
      "median": -0.01851851851851849,
      "n": 49,
      "negative_fraction": 0.5714285714285714
    }
  },
  "per_variant": {
    "V1": {
      "mean": -0.020723104056437385,
      "median": 0.0,
      "n": 42,
      "negative_fraction": 0.40476190476190477,
      "positive_fraction": 0.0
    },
    "V2": {
      "mean": -0.03968253968253969,
      "median": -0.03703703703703709,
      "n": 42,
      "negative_fraction": 0.7142857142857143,
      "positive_fraction": 0.0
    },
    "V3": {
      "mean": -0.054232804232804244,
      "median": -0.03703703703703709,
      "n": 42,
      "negative_fraction": 0.7619047619047619,
      "positive_fraction": 0.0
    },
    "V4": {
      "mean": -0.05202821869488536,
      "median": -0.03703703703703709,
      "n": 42,
      "negative_fraction": 0.6904761904761905,
      "positive_fraction": 0.0
    },
    "V5": {
      "mean": -0.03571428571428571,
      "median": -0.01851851851851849,
      "n": 42,
      "negative_fraction": 0.7857142857142857,
      "positive_fraction": 0.0
    },
    "V6": {
      "mean": -0.03791887125220458,
      "median": -0.01851851851851849,
      "n": 42,
      "negative_fraction": 0.6904761904761905,
      "positive_fraction": 0.0
    },
    "V7": {
      "mean": -0.04894179894179894,
      "median": -0.01851851851851849,
      "n": 42,
      "negative_fraction": 0.6666666666666666,
      "positive_fraction": 0.0
    }
  },
  "positive_fraction": 0.0,
  "variants_with_negative_mean": 7,
  "zero_fraction": 0.32653061224489793
}
```

## F5
```json
{
  "depth_geometry_accessibility": {
    "25_to_120": {
      "n_pairs": 15,
      "pearson": -0.07198419138525107,
      "pearson_null_95": [
        -0.42758102351949157,
        0.5150372643052186
      ],
      "pearson_perm_p_one_sided": 0.563043695630437,
      "spearman": -0.1928571428571428,
      "spearman_null_95": [
        -0.44642857142857145,
        0.575
      ],
      "spearman_perm_p_one_sided": 0.7256274372562743,
      "variants": [
        "V2",
        "V3",
        "V4",
        "V5",
        "V6",
        "V7"
      ]
    },
    "50_to_120": {
      "n_pairs": 15,
      "pearson": 0.504906217468644,
      "pearson_null_95": [
        -0.4018448791200654,
        0.5503752423602841
      ],
      "pearson_perm_p_one_sided": 0.048595140485951406,
      "spearman": 0.5249999999999999,
      "spearman_null_95": [
        -0.44642857142857145,
        0.5892857142857143
      ],
      "spearman_perm_p_one_sided": 0.0481951804819518,
      "variants": [
        "V2",
        "V3",
        "V4",
        "V5",
        "V6",
        "V7"
      ]
    }
  },
  "intervention": {
    "25_to_120": {
      "n_pairs": 15,
      "pearson": 0.629165364474182,
      "pearson_null_95": [
        -0.5198756720449774,
        0.5689085627235506
      ],
      "pearson_perm_p_one_sided": 0.0044995500449955,
      "spearman": 0.5821428571428571,
      "spearman_null_95": [
        -0.5394642857142855,
        0.5571428571428572
      ],
      "spearman_perm_p_one_sided": 0.014698530146985302,
      "variants": [
        "V2",
        "V3",
        "V4",
        "V5",
        "V6",
        "V7"
      ]
    },
    "50_to_120": {
      "n_pairs": 15,
      "pearson": 0.24155901216973713,
      "pearson_null_95": [
        -0.619644246317242,
        0.5677022096217486
      ],
      "pearson_perm_p_one_sided": 0.25007499250074994,
      "spearman": 0.1857142857142857,
      "spearman_null_95": [
        -0.5607142857142857,
        0.5357142857142857
      ],
      "spearman_perm_p_one_sided": 0.2652734726527347,
      "variants": [
        "V2",
        "V3",
        "V4",
        "V5",
        "V6",
        "V7"
      ]
    }
  },
  "reference": {
    "25_to_120": {
      "n_pairs": 15,
      "pearson": 0.15769447335368306,
      "pearson_null_95": [
        -0.45449086148660534,
        0.5329149387936468
      ],
      "pearson_perm_p_one_sided": 0.29077092290770923,
      "spearman": 0.2071428571428571,
      "spearman_null_95": [
        -0.43214285714285716,
        0.49642857142857144
      ],
      "spearman_perm_p_one_sided": 0.2308769123087691,
      "variants": [
        "V2",
        "V3",
        "V4",
        "V5",
        "V6",
        "V7"
      ]
    },
    "50_to_120": {
      "n_pairs": 15,
      "pearson": 0.40549294558713794,
      "pearson_null_95": [
        -0.44698444572007046,
        0.5325701056819531
      ],
      "pearson_perm_p_one_sided": 0.08099190080991901,
      "spearman": 0.42499999999999993,
      "spearman_null_95": [
        -0.42142857142857143,
        0.5285714285714286
      ],
      "spearman_perm_p_one_sided": 0.08959104089591041,
      "variants": [
        "V2",
        "V3",
        "V4",
        "V5",
        "V6",
        "V7"
      ]
    }
  }
}
```
