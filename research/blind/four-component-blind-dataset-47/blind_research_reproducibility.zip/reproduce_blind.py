#!/usr/bin/env python3
"""Reproduce pre-unblinding numeric checks from ONLY the specified blind ZIP.

Usage: python reproduce_blind.py four-component-blind-dataset-47.zip
No GitHub access; no repo files; Python standard library only.
"""
import sys, zipfile, json, hashlib, statistics, csv
from collections import defaultdict, Counter
from pathlib import Path

if len(sys.argv) != 2:
    raise SystemExit('Usage: python reproduce_blind.py /path/to/four-component-blind-dataset-47.zip')
path = Path(sys.argv[1]); b = path.read_bytes()
print('artifact_sha256', hashlib.sha256(b).hexdigest())
with zipfile.ZipFile(path) as z:
    names = z.namelist()
    assert names == ['four-component-blind-dataset.json'], 'Unrecognized artifact layout'
    raw = z.read(names[0]); data = json.loads(raw)
print('dataset_sha256',hashlib.sha256(raw).hexdigest())
assert len(data['rows']) == 47
assert len(data['full_layer_reports']) == 47
assert list(sorted(data['complete_token_points_m'])) == [25,50,75,100,110,120]
rows = data['rows']; reports = data['full_layer_reports']
all_layers = []
for key, report in reports.items():
    assert len(report['layers']) == 7
    for name, d in report['layers'].items():
        n = 7 if name == 'final' else int(name.split('_')[1])
        x = dict(variant=report['variant_id'],tokens=report['tokens_m'],layer=n)
        x.update({metric:d[metric] for metric in ['B_structure_score', 'B_condition_1_accuracy','B_under_C_accuracy','B_under_D_accuracy','B_invariance_under_A_intervention','A_axis_consistency','A_effect_magnitude','A_B_factorization_score']})
        x['B_margin']=d['B_cluster']['margin']
        x['C_margin']=d['C_relative_to_B']['relation_margin']
        for mode in ('zero','negate','shuffle'):
            x['B_acc_'+mode]=d['B_intervention_accuracy_by_A_mode'][mode]
        ref = d.get('learned_A_reference')
        x['C_ref_advantage'] = ref['learned_A_advantage_for_C_reference'] if ref else None
        all_layers.append(x)
assert len(all_layers) == 329
complete = [x for x in all_layers if x['tokens']<=120]
assert len(complete) == 294
active = [x for x in complete if x['variant']!='V1']
assert len(active)==252

# Exact-score formula check, all 329 independent of implementation/code.
for x in all_layers:
    inv=(x['B_acc_zero']+x['B_acc_negate']+x['B_acc_shuffle'])/3
    b_score=0.3*(x['B_condition_1_accuracy']+x['B_under_C_accuracy']+x['B_under_D_accuracy']+inv)-0.2
    factor=x['A_axis_consistency']*(1.2*inv-0.2)
    assert abs(inv-x['B_invariance_under_A_intervention'])<1e-12
    assert abs(b_score-x['B_structure_score'])<1e-12
    assert abs(factor-x['A_B_factorization_score'])<1e-12
print('exact_score_identities',len(all_layers),'/',len(all_layers))

by_checkpoint=defaultdict(dict)
for x in complete:by_checkpoint[(x['variant'],x['tokens'])][x['layer']]=x
assert len(by_checkpoint)==42
assert len({v for v,t in by_checkpoint})==7
assert all(len(ls)==7 for ls in by_checkpoint.values())

for metric in ['B_margin','C_margin']:
    dip=sum(ls[2][metric]<ls[1][metric] and ls[2][metric]<ls[3][metric] for ls in by_checkpoint.values())
    print('layer2_dip_'+metric,dip,'/ 42')
    assert dip==42

axis_early=0; norm_late=0; axis_before_norm=0; axis_f_ret=[];norm_f_ret=[]
for (v,t),ls in by_checkpoint.items():
    if v=='V1':
        assert all(ls[i]['A_effect_magnitude']==0 and ls[i]['A_axis_consistency']==0 for i in range(1,8))
        continue
    best_axis=max(range(1,7),key=lambda i:ls[i]['A_axis_consistency'])
    best_norm=max(range(1,7),key=lambda i:ls[i]['A_effect_magnitude'])
    axis_early += best_axis in (1,2)
    norm_late += best_norm in (5,6)
    axis_before_norm += best_axis < best_norm
    axis_f_ret.append(ls[7]['A_axis_consistency']/ls[best_axis]['A_axis_consistency'])
    norm_f_ret.append(ls[7]['A_effect_magnitude']/ls[best_norm]['A_effect_magnitude'])
print('active checkpoints / axis peak at layer1-2',axis_early,'/36')
print('active checkpoints / effect peak at layer5-6',norm_late,'/36')
print('axis peak earlier than effect peak',axis_before_norm,'/36')
print('best-layer retention axis, effect',round(statistics.mean(axis_f_ret),4),round(statistics.mean(norm_f_ret),4))
assert (axis_early,norm_late,axis_before_norm)==(36,33,36)

for v in ('V1','V2','V3','V4','V5','V6','V7'):
    s={x['tokens_m']:x for x in rows if x['variant_id']==v and x['tokens_m']<=120}
    assert len(s)==6
    if v != 'V1':
        ratio=s[120]['A_effect_magnitude']/s[25]['A_effect_magnitude']
        signs=''.join('+' if s[t]['learned_A_advantage_for_C_reference']>0 else '-' for t in sorted(s))
        print(v, 'A effect (25 to120) ratio',round(ratio,3),'learned-A C reference signs',signs)
    else: print(v,'A effect zero throughout full coverage; learned-A reference absent')

for metric in ['B_condition_1_accuracy','B_under_C_accuracy','B_under_D_accuracy']:
    print(metric,'perfect layer observations',sum(x[metric]==1 for x in complete),'/',len(complete))

print('130M variants',sorted(r['variant_id'] for r in rows if r['tokens_m']==130))
print('BLIND_CHECKS_PASS')
